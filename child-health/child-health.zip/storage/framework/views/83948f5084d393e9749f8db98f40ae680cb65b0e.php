<?php
    $edit = !is_null($dataTypeContent->getKey());
    $add  = is_null($dataTypeContent->getKey());
?>



<?php $__env->startSection('css'); ?>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_title', __('voyager::generic.'.($edit ? 'edit' : 'add')).' Niño/Niña '); ?>

<?php $__env->startSection('page_header'); ?>
    <h1 class="page-title">
        <i class="<?php echo e($dataType->icon); ?>"></i>
        <?php echo e(__('voyager::generic.'.($edit ? 'edit' : 'add')).' Niño/Niña '); ?>

    </h1>
    <?php echo $__env->make('voyager::multilingual.language-selector', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-content edit-add container-fluid">
        <div class="row">
            <div class="col-md-12">

                <div class="panel panel-bordered">
                    <!-- form start -->
                    <form role="form"
                            class="form-edit-add"
                            action="<?php echo e($edit ? '/admin/children/'.$dataTypeContent->id : '/admin/children'); ?>"
                            method="POST" enctype="multipart/form-data">
                        <!-- PUT Method if we are editing -->
                        <?php if($edit): ?>
                            <?php echo e(method_field("PUT")); ?>

                        <?php endif; ?>

                        <!-- CSRF TOKEN -->
                        <?php echo e(csrf_field()); ?>


                        <div class="panel-body">

                            <?php if(count($errors) > 0): ?>
                                <div class="alert alert-danger">
                                    <ul>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            <?php endif; ?>

                            <!-- Adding / Editing -->
                            <?php
                                $dataTypeRows = $dataType->{($edit ? 'editRows' : 'addRows' )};
                            ?>
                            <!-- <div class="col-md-12">
                                <label for="">Cedula de Identidad</label>
                                <input type="number" class="form-control" id="dni">
                            </div> -->
                            <?php $__currentLoopData = $dataTypeRows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                                <!-- GET THE DISPLAY OPTIONS -->
                                <?php if($row->id!=9&&$row->id!=10): ?>
                                    <?php
                                        $display_options = $row->details->display ?? NULL;
                                        if ($dataTypeContent->{$row->field.'_'.($edit ? 'edit' : 'add')}) {
                                            $dataTypeContent->{$row->field} = $dataTypeContent->{$row->field.'_'.($edit ? 'edit' : 'add')};
                                        }
                                    ?>
                                    <?php if(isset($row->details->legend) && isset($row->details->legend->text)): ?>
                                        <legend class="text-<?php echo e($row->details->legend->align ?? 'center'); ?>" style="background-color: <?php echo e($row->details->legend->bgcolor ?? '#f0f0f0'); ?>;padding: 5px;"><?php echo e($row->details->legend->text); ?></legend>
                                    <?php endif; ?>

                                    <div class="form-group <?php if($row->type == 'hidden'): ?> hidden <?php endif; ?> col-md-<?php echo e($display_options->width ?? 12); ?> <?php echo e($errors->has($row->field) ? 'has-error' : ''); ?>" <?php if(isset($display_options->id)): ?><?php echo e("id=$display_options->id"); ?><?php endif; ?>>
                                        <?php echo e($row->slugify); ?>

                                        <label class="control-label" for="name"><?php echo e($row->display_name); ?></label>
                                        <?php echo $__env->make('voyager::multilingual.input-hidden-bread-edit-add', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        <?php if(isset($row->details->view)): ?>
                                            <?php echo $__env->make($row->details->view, ['row' => $row, 'dataType' => $dataType, 'dataTypeContent' => $dataTypeContent, 'content' => $dataTypeContent->{$row->field}, 'action' => ($edit ? 'edit' : 'add')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        <?php elseif($row->type == 'relationship'): ?>
                                            <?php echo $__env->make('voyager::formfields.relationship', ['options' => $row->details], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        <?php else: ?>
                                            <?php echo app('voyager')->formField($row, $dataType, $dataTypeContent); ?>

                                        <?php endif; ?>

                                        <?php $__currentLoopData = app('voyager')->afterFormFields($row, $dataType, $dataTypeContent); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $after): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo $after->handle($row, $dataType, $dataTypeContent); ?>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($errors->has($row->field)): ?>
                                            <?php $__currentLoopData = $errors->get($row->field); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <span class="help-block"><?php echo e($error); ?></span>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </div>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-12">
                                <label for="">Seleccione Pais</label>
                                
                                <select name="country_id" id="country_id" class="form-control select2" onchange="searchStateCountry()">
                                    <option value="">Seleccione Pais</option>
                                    <?php $__currentLoopData = $Country; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($country->id); ?>" <?php echo e(isset($dataTypeContent->country_id)&&$dataTypeContent->country_id==$country->id?'selected':''); ?>><?php echo e($country->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-md-12 state_id">
                                
                            </div>
                            <div class="col-md-12 municipality_id">
                                
                            </div>
                            <div class="col-md-12 parish_id">
                                
                            </div>
                            <div class="col-md-12">
                                <label for="">Direccion de habitacion</label>
                                <textarea class="form-control" name="address" id="addresss" cols="30" rows="10"><?php echo e(isset($dataTypeContent->address)?$dataTypeContent->address:""); ?></textarea>
                            </div>
                            

                        </div><!-- panel-body -->

                        <div class="panel-footer">
                            <?php $__env->startSection('submit-buttons'); ?>
                                <button type="submit" class="btn btn-primary save"><?php echo e(__('voyager::generic.save')); ?></button>
                            <?php $__env->stopSection(); ?>
                            <?php echo $__env->yieldContent('submit-buttons'); ?>
                        </div>
                    </form>

                    <iframe id="form_target" name="form_target" style="display:none"></iframe>
                    <form id="my_form" action="<?php echo e(route('voyager.upload')); ?>" target="form_target" method="post"
                            enctype="multipart/form-data" style="width:0;height:0;overflow:hidden">
                        <input name="image" id="upload_file" type="file"
                                 onchange="$('#my_form').submit();this.value='';">
                        <input type="hidden" name="type_slug" id="type_slug" value="<?php echo e($dataType->slug); ?>">
                        <?php echo e(csrf_field()); ?>

                    </form>

                </div>
            </div>
        </div>
    </div>

    <div class="modal fade modal-danger" id="confirm_delete_modal">
        <div class="modal-dialog">
            <div class="modal-content">

                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal"
                            aria-hidden="true">&times;</button>
                    <h4 class="modal-title"><i class="voyager-warning"></i> <?php echo e(__('voyager::generic.are_you_sure')); ?></h4>
                </div>

                <div class="modal-body">
                    <h4><?php echo e(__('voyager::generic.are_you_sure_delete')); ?> '<span class="confirm_delete_name"></span>'</h4>
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo e(__('voyager::generic.cancel')); ?></button>
                    <button type="button" class="btn btn-danger" id="confirm_delete"><?php echo e(__('voyager::generic.delete_confirm')); ?></button>
                </div>
            </div>
        </div>
    </div>
    <!-- End Delete File Modal -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
    <script>
        var params = {};
        var $file;

        function deleteHandler(tag, isMulti) {
          return function() {
            $file = $(this).siblings(tag);

            params = {
                slug:   '<?php echo e($dataType->slug); ?>',
                filename:  $file.data('file-name'),
                id:     $file.data('id'),
                field:  $file.parent().data('field-name'),
                multi: isMulti,
                _token: '<?php echo e(csrf_token()); ?>'
            }

            $('.confirm_delete_name').text(params.filename);
            $('#confirm_delete_modal').modal('show');
          };
        }

        $('document').ready(function () {
            $('.toggleswitch').bootstrapToggle();

            //Init datepicker for date fields if data-datepicker attribute defined
            //or if browser does not handle date inputs
            $('.form-group input[type=date]').each(function (idx, elt) {
                if (elt.type != 'date' || elt.hasAttribute('data-datepicker')) {
                    elt.type = 'text';
                    $(elt).datetimepicker($(elt).data('datepicker'));
                }
            });

            <?php if($isModelTranslatable): ?>
                $('.side-body').multilingual({"editing": true});
            <?php endif; ?>

            $('.side-body input[data-slug-origin]').each(function(i, el) {
                $(el).slugify();
            });

            $('.form-group').on('click', '.remove-multi-image', deleteHandler('img', true));
            $('.form-group').on('click', '.remove-single-image', deleteHandler('img', false));
            $('.form-group').on('click', '.remove-multi-file', deleteHandler('a', true));
            $('.form-group').on('click', '.remove-single-file', deleteHandler('a', false));

            $('#confirm_delete').on('click', function(){
                $.post('<?php echo e(route('voyager.media.remove')); ?>', params, function (response) {
                    if ( response
                        && response.data
                        && response.data.status
                        && response.data.status == 200 ) {

                        toastr.success(response.data.message);
                        $file.parent().fadeOut(300, function() { $(this).remove(); })
                    } else {
                        toastr.error("Error removing file.");
                    }
                });

                $('#confirm_delete_modal').modal('hide');
            });
            $('[data-toggle="tooltip"]').tooltip();
        });
    </script>
    <script>
        function searchStateCountry(){
            var country_id=$("#country_id").val()
            var url="/admin/"+country_id+"/searchStateCountry" ;
            var state="state_id";
            var label="Seleccione Estado";
            var state_id='<?php echo e(isset($dataTypeContent->state_id)?$dataTypeContent->state_id:""); ?>';
            var functions="searchMunicipalityState()";
            ajax(url,state,label,functions,state_id);
            // console.log(country_id);
        }
        function searchMunicipalityState(){
            var state_id=$("#state_id").val();
            // alert(state_id==null);
            if(state_id==null){
                state_id="<?php echo e(isset($dataTypeContent->state_id)?$dataTypeContent->state_id:''); ?>";
            }
            var url="/admin/"+state_id+"/searchMunicipalityState" ;
            var state="municipality_id";
            var label="Seleccione Municipio";
            
            var municipality_id="<?php echo e(isset($dataTypeContent->municipality_id)?$dataTypeContent->municipality_id:""); ?>";
            
            var functions="searchParishMunicipality()";
            ajax(url,state,label,functions,municipality_id);
            // console.log(data);
        }
        function searchParishMunicipality(){
            var municipality_id=$("#municipality_id").val();
            if(municipality_id==null){
                municipality_id='<?php echo e(isset($dataTypeContent->municipality_id)?$dataTypeContent->municipality_id:""); ?>';
            }
            var url="/admin/"+municipality_id+"/searchParishMunicipality" ;
            var state="parish_id";
            var label="Seleccione Parroquia";
            var parish_id='<?php echo e(isset($dataTypeContent->parish_id)?$dataTypeContent->parish_id:""); ?>';
            var functions="";
            ajax(url,state,label,functions,parish_id);
            // console.log(data);
        }
        function ajax(url,div,label,functions,dataSelected){
            console.log(functions);
            var html="";
            var selected="";
            $.ajax({
                dataType: "json",
                method:'get',
                url:url,    
                success:function(data){
                    $("."+div).html("");
                    console.log(data);
                    html+="<label>"+label+"</label>";
                    html+='<select name="'+div+'" id="'+div+'" class="form-control select2" onchange="'+functions+'">';
                        html+='<option value="">'+label+'</option>';
                        for(var i=0;i<data.length;i++){
                            if(dataSelected==data[i].id){
                                selected="selected";
                            }else{
                                selected="";
                            }
                            html+='<option value="'+data[i].id+'" '+selected+'>'+data[i].name+'</option>';
                        }
                    html+="</select>";
                    $("."+div).append(html);                    
                }
            });
        }
        $("select[name='pathology_id']").attr("disabled","disabled");
        var band=0;
        $("input[name='pathology']").change(function(){
            if(band==0){
                $("select[name='pathology_id']").removeAttr('disabled');
                band=1;
            }else{
                $("select[name='pathology_id']").attr("disabled","disabled");
                band=0;
            }
        });
    </script>
    <script>
        <?php if(isset($dataTypeContent)): ?>
            searchStateCountry();
            searchMunicipalityState();
            searchParishMunicipality();
        <?php endif; ?>
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('voyager::master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\child-health\child-health\resources\views/vendor/voyager/children/edit-add.blade.php ENDPATH**/ ?>