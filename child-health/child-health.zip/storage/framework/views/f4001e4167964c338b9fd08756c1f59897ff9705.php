<?php $__env->startSection('page_header'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-content browse container-fluid">
        <?php echo $__env->make('voyager::alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-bordered">
                    <div class="panel-body">
                        <div class="col-md-12">
                        <label for="">1 Puntuacion Z talla segun la edad ninas</label>
                            <div id="graficZScoreGirl"></div>
                        </div>
                        <div class="col-md-12">
                            <label for="">2 Puntuacion Z talla segun la edad ninos</label>
                            <div id="graficZScoreLengthBoy"></div>
                        </div>
                        <div class="col-md-12">
                            <label for="">3 Puntuacion Z Peso segun la edad ninas</label>
                            <div id="graficZScoreWeightGirl"></div>
                        </div>
                        <div class="col-md-12">
                            <label for="">4 Puntuacion Z Peso segun la edad ninos</label>
                            <div id="graficZScoreWeightBoy"></div>
                        </div>
                        <div class="col-md-12">
                            <label for="">5 Puntuacion Z Peso por talla ninas</label>
                            <div id="graficZScoreWeightForLenghtGirl"></div>
                        </div>
                        <div class="col-md-12">
                            <label for="">6 Puntuacion Z Peso por height ninas</label>
                            <div id="graficZScoreWeightForHeightGirl"></div>
                        </div>
                        <div class="col-md-12">
                            <label for="">7 Puntuacion Z Peso por talla ninos</label>
                            <div id="graficZScoreWeightForLenghtBoy"></div>
                        </div>
                        <div class="col-md-12">
                            <label for="">8 Puntuacion Z Peso por height ninos</label>
                            <div id="graficZScoreWeightForHeightBoy"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link href="<?php echo e(asset('vendor/css/charts-c3js/c3.min.css')); ?>" rel="stylesheet" type="text/css">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
<script src="<?php echo e(asset('vendor/js/d3/d3.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/js/charts-c3js/c3.min.js')); ?>"></script>

    
    <script>
        var graficZScoreGirl=[];
        var i=0,j=0,k=0;
        <?php for($i=0;$i<count($graficZScoreGirl);$i++): ?>
        graficZScoreGirl[i]=new Array();
            j=0;
            k=0;
            <?php for($j=0;$j<364;$j++): ?>
                if(j==0){
                    graficZScoreGirl[i][k]="<?php echo e($graficZScoreGirl[$i][$j]); ?>";
                    k++;
                    graficZScoreGirl[i][k]=<?php echo e($graficZScoreGirl[$i][$j+1]); ?>

                    k++;
                }
                else{ 
                    if(j%7==0){
                        graficZScoreGirl[i][k]=<?php echo e($graficZScoreGirl[$i][$j]); ?>

                        k++;
                    }
                }
                j++;
            <?php endfor; ?>
            i++;
        <?php endfor; ?>
        console.log(graficZScoreGirl)
        var chart = c3.generate({
            bindto: '#graficZScoreGirl',
            data: {
                columns:graficZScoreGirl ,
                type: 'spline'
            }
        });

    </script>

    <script>
        var graficZScoreLengthBoy=[];
        var i=0,j=0,k=0;
        <?php for($i=0;$i<count($graficZScoreLengthBoy);$i++): ?>
        graficZScoreLengthBoy[i]=new Array();
            j=0;
            k=0;
            <?php for($j=0;$j<364;$j++): ?>
                if(j==0){
                    graficZScoreLengthBoy[i][k]="<?php echo e($graficZScoreLengthBoy[$i][$j]); ?>";
                    k++;
                    graficZScoreLengthBoy[i][k]=<?php echo e($graficZScoreLengthBoy[$i][$j+1]); ?>

                    k++;
                }
                else{ 
                    if(j%7==0){
                        graficZScoreLengthBoy[i][k]=<?php echo e($graficZScoreLengthBoy[$i][$j]); ?>

                        k++;
                    }
                }
                j++;
            <?php endfor; ?>
            i++;
        <?php endfor; ?>
        console.log(graficZScoreLengthBoy)
        var graficZScoreLengthBoy = c3.generate({
            bindto: '#graficZScoreLengthBoy',
            data: {
                columns:graficZScoreLengthBoy ,
                type: 'spline'
            }
        });

    </script>

    <script>
        var graficZScoreWeightGirl=[];
        var i=0,j=0,k=0;
        <?php for($i=0;$i<count($graficZScoreWeightGirl);$i++): ?>
        graficZScoreWeightGirl[i]=new Array();
            j=0;
            k=0;
            <?php for($j=0;$j<364;$j++): ?>
                if(j==0){
                    graficZScoreWeightGirl[i][k]="<?php echo e($graficZScoreWeightGirl[$i][$j]); ?>";
                    k++;
                    graficZScoreWeightGirl[i][k]=<?php echo e($graficZScoreWeightGirl[$i][$j+1]); ?>

                    k++;
                }
                else{ 
                    if(j%7==0){
                        graficZScoreWeightGirl[i][k]=<?php echo e($graficZScoreWeightGirl[$i][$j]); ?>

                        k++;
                    }
                }
                j++;
            <?php endfor; ?>
            i++;
        <?php endfor; ?>
        console.log(graficZScoreWeightGirl)
        var graficZScoreWeightGirl = c3.generate({
            bindto: '#graficZScoreWeightGirl',
            data: {
                columns:graficZScoreWeightGirl ,
                type: 'spline'
            }
        });

    </script>

    <script>
        var graficZScoreWeightBoy=[];
        var i=0,j=0,k=0;
        <?php for($i=0;$i<count($graficZScoreWeightBoy);$i++): ?>
        graficZScoreWeightBoy[i]=new Array();
            j=0;
            k=0;
            <?php for($j=0;$j<364;$j++): ?>
                if(j==0){
                    graficZScoreWeightBoy[i][k]="<?php echo e($graficZScoreWeightBoy[$i][$j]); ?>";
                    k++;
                    graficZScoreWeightBoy[i][k]=<?php echo e($graficZScoreWeightBoy[$i][$j+1]); ?>

                    k++;
                }
                else{ 
                    if(j%7==0){
                        graficZScoreWeightBoy[i][k]=<?php echo e($graficZScoreWeightBoy[$i][$j]); ?>

                        k++;
                    }
                }
                j++;
            <?php endfor; ?>
            i++;
        <?php endfor; ?>
        console.log(graficZScoreWeightBoy)
        var graficZScoreWeightBoy = c3.generate({
            bindto: '#graficZScoreWeightBoy',
            data: {
                columns:graficZScoreWeightBoy ,
                type: 'spline'
            }
        });

    </script>

    <script>
        var graficZScoreWeightForLenghtGirl=[];
        var i=0,j=0,k=0;
        <?php for($i=0;$i<count($graficZScoreWeightForLenghtGirl);$i++): ?>
        graficZScoreWeightForLenghtGirl[i]=new Array();
            j=0;
            k=0;
            <?php for($j=0;$j<364;$j++): ?>
                if(j==0){
                    graficZScoreWeightForLenghtGirl[i][k]="<?php echo e($graficZScoreWeightForLenghtGirl[$i][$j]); ?>";
                    k++;
                    graficZScoreWeightForLenghtGirl[i][k]=<?php echo e($graficZScoreWeightForLenghtGirl[$i][$j+1]); ?>

                    k++;
                }
                else{ 
                    if(j%1==0){
                        graficZScoreWeightForLenghtGirl[i][k]=<?php echo e($graficZScoreWeightForLenghtGirl[$i][$j]); ?>

                        k++;
                    }
                }
                j++;
            <?php endfor; ?>
            i++;
        <?php endfor; ?>
        console.log(graficZScoreWeightForLenghtGirl)
        var graficZScoreWeightForLenghtGirl = c3.generate({
            bindto: '#graficZScoreWeightForLenghtGirl',
            data: {
                columns:graficZScoreWeightForLenghtGirl ,
                type: 'spline'
            }
        });

    </script>

    <script>
        var graficZScoreWeightForHeightGirl=[];
        var i=0,j=0,k=0;
        <?php for($i=0;$i<count($graficZScoreWeightForHeightGirl);$i++): ?>
        graficZScoreWeightForHeightGirl[i]=new Array();
            j=0;
            k=0;
            <?php for($j=0;$j<364;$j++): ?>
                if(j==0){
                    graficZScoreWeightForHeightGirl[i][k]="<?php echo e($graficZScoreWeightForHeightGirl[$i][$j]); ?>";
                    k++;
                    graficZScoreWeightForHeightGirl[i][k]=<?php echo e($graficZScoreWeightForHeightGirl[$i][$j+1]); ?>

                    k++;
                }
                else{ 
                    if(j%1==0){
                        graficZScoreWeightForHeightGirl[i][k]=<?php echo e($graficZScoreWeightForHeightGirl[$i][$j]); ?>

                        k++;
                    }
                }
                j++;
            <?php endfor; ?>
            i++;
        <?php endfor; ?>
        console.log(graficZScoreWeightForHeightGirl)
        var graficZScoreWeightForHeightGirl = c3.generate({
            bindto: '#graficZScoreWeightForHeightGirl',
            data: {
                columns:graficZScoreWeightForHeightGirl ,
                type: 'spline'
            }
        });

    </script>

    <script>
        var graficZScoreWeightForLenghtBoy=[];
        var i=0,j=0,k=0;
        <?php for($i=0;$i<count($graficZScoreWeightForLenghtBoy);$i++): ?>
        graficZScoreWeightForLenghtBoy[i]=new Array();
            j=0;
            k=0;
            <?php for($j=0;$j<364;$j++): ?>
                if(j==0){
                    graficZScoreWeightForLenghtBoy[i][k]="<?php echo e($graficZScoreWeightForLenghtBoy[$i][$j]); ?>";
                    k++;
                    graficZScoreWeightForLenghtBoy[i][k]=<?php echo e($graficZScoreWeightForLenghtBoy[$i][$j+1]); ?>

                    k++;
                }
                else{ 
                    if(j%1==0){
                        graficZScoreWeightForLenghtBoy[i][k]=<?php echo e($graficZScoreWeightForLenghtBoy[$i][$j]); ?>

                        k++;
                    }
                }
                j++;
            <?php endfor; ?>
            i++;
        <?php endfor; ?>
        console.log(graficZScoreWeightForLenghtBoy)
        var graficZScoreWeightForLenghtBoy = c3.generate({
            bindto: '#graficZScoreWeightForLenghtBoy',
            data: {
                columns:graficZScoreWeightForLenghtBoy ,
                type: 'spline'
            }
        });

    </script>

    <script>
        var graficZScoreWeightForHeightBoy=[];
        var i=0,j=0,k=0;
        <?php for($i=0;$i<count($graficZScoreWeightForHeightBoy);$i++): ?>
        graficZScoreWeightForHeightBoy[i]=new Array();
            j=0;
            k=0;
            <?php for($j=0;$j<364;$j++): ?>
                if(j==0){
                    graficZScoreWeightForHeightBoy[i][k]="<?php echo e($graficZScoreWeightForHeightBoy[$i][$j]); ?>";
                    k++;
                    graficZScoreWeightForHeightBoy[i][k]=<?php echo e($graficZScoreWeightForHeightBoy[$i][$j+1]); ?>

                    k++;
                }
                else{ 
                    if(j%1==0){
                        graficZScoreWeightForHeightBoy[i][k]=<?php echo e($graficZScoreWeightForHeightBoy[$i][$j]); ?>

                        k++;
                    }
                }
                j++;
            <?php endfor; ?>
            i++;
        <?php endfor; ?>
        console.log(graficZScoreWeightForHeightBoy)
        var graficZScoreWeightForHeightBoy = c3.generate({
            bindto: '#graficZScoreWeightForHeightBoy',
            data: {
                columns:graficZScoreWeightForHeightBoy ,
                type: 'spline'
            }
        });

    </script>

    <script>
        var graficZScoreWeightForHeightBoy=[];
        var i=0,j=0,k=0;
        <?php for($i=0;$i<count($graficZScoreWeightForHeightBoy);$i++): ?>
        graficZScoreWeightForHeightBoy[i]=new Array();
            j=0;
            k=0;
            <?php for($j=0;$j<364;$j++): ?>
                if(j==0){
                    graficZScoreWeightForHeightBoy[i][k]="<?php echo e($graficZScoreWeightForHeightBoy[$i][$j]); ?>";
                    k++;
                    graficZScoreWeightForHeightBoy[i][k]=<?php echo e($graficZScoreWeightForHeightBoy[$i][$j+1]); ?>

                    k++;
                }
                else{ 
                    if(j%1==0){
                        graficZScoreWeightForHeightBoy[i][k]=<?php echo e($graficZScoreWeightForHeightBoy[$i][$j]); ?>

                        k++;
                    }
                }
                j++;
            <?php endfor; ?>
            i++;
        <?php endfor; ?>
        console.log(graficZScoreWeightForHeightBoy)
        var graficZScoreWeightForHeightBoy = c3.generate({
            bindto: '#graficZScoreWeightForHeightBoy',
            data: {
                columns:graficZScoreWeightForHeightBoy ,
                type: 'spline'
            }
        });

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('voyager::master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\child-health\child-health\resources\views/voyager/grafica/browse.blade.php ENDPATH**/ ?>