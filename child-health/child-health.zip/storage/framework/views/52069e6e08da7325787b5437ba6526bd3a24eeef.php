<?php $__env->startSection('page_title', __('voyager::generic.viewing').' '.'Reportes'); ?>

<?php $__env->startSection('page_header'); ?>
    <div class="container-fluid">
        <h1 class="page-title">
            <?php echo e('Reportes'); ?>

        </h1>
       
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-content browse container-fluid">
        <?php echo $__env->make('voyager::alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-bordered">
                    <div class="panel-body">
                        <div class="row">
                            <div class="col-md-12 text-center">
                                <label for="">Inventario de formulas del total recibido, cuanto queda y cuanto se ha repartido</label>
                                <div id="InventoryTotalReceivedAndDelivered"></div>
                            </div>
                            <div class="col-md-6 text-center">
                                <label for="">Cantida de pacientes atendidos</label>
                                <div id="childrensAattended"></div>

                            </div>
                        </div>  
                    </div>
                </div>
            </div>
        </div>
    </div>

    
    <div class="modal modal-danger fade" tabindex="-1" id="delete_modal" role="dialog">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="<?php echo e(__('voyager::generic.close')); ?>"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title"><i class="voyager-trash"></i></h4>
                </div>
                <div class="modal-footer">
                    <form action="#" id="delete_form" method="POST">
                        <?php echo e(method_field('DELETE')); ?>

                        <?php echo e(csrf_field()); ?>

                        <input type="submit" class="btn btn-danger pull-right delete-confirm" value="<?php echo e(__('voyager::generic.delete_confirm')); ?>">
                    </form>
                    <button type="button" class="btn btn-default pull-right" data-dismiss="modal"><?php echo e(__('voyager::generic.cancel')); ?></button>
                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link href="<?php echo e(asset('vendor/css/charts-c3js/c3.min.css')); ?>" rel="stylesheet" type="text/css">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
    <!-- DataTables -->
    <script src="<?php echo e(asset('vendor/js/d3/d3.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/js/charts-c3js/c3.min.js')); ?>"></script>
    <script>
        var graphicInventoryTotalReceivedAndDelivered=[[],[],[],[]];
        i=0;
        
        <?php for($i=0;$i<count($graphicInventoryTotalReceivedAndDelivered);$i++): ?>
       
            graphicInventoryTotalReceivedAndDelivered[i][0]='<?php echo e($graphicInventoryTotalReceivedAndDelivered[$i][0]); ?>';
            graphicInventoryTotalReceivedAndDelivered[i][1]='<?php echo e($graphicInventoryTotalReceivedAndDelivered[$i][1]); ?>';
            graphicInventoryTotalReceivedAndDelivered[i][2]='<?php echo e($graphicInventoryTotalReceivedAndDelivered[$i][2]); ?>';
            graphicInventoryTotalReceivedAndDelivered[i][3]='<?php echo e($graphicInventoryTotalReceivedAndDelivered[$i][3]); ?>';
            console.log(graphicInventoryTotalReceivedAndDelivered);
            i++;
        <?php endfor; ?>
        var InventoryTotalReceivedAndDelivered = c3.generate({
            bindto: '#InventoryTotalReceivedAndDelivered',
            data: {
                x : 'x',
                columns: graphicInventoryTotalReceivedAndDelivered,
                type: 'bar'
            },
            
            axis: {
                x: {
                    type: 'category', // this needed to load string x value
                    label: {
                        text: 'Distintas formulas entregadas',
                        position: 'outer-center'
                    }

                },
                y:{
                    label: {
                        text: 'Cantidad de formulas entregadas',
                        position: 'outer-center'
                    }
                }
                
            }
        });
    </script>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('voyager::master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\child-health\child-health\resources\views/vendor/voyager/reportes/browse.blade.php ENDPATH**/ ?>