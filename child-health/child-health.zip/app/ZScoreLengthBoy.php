<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class ZScoreLengthBoy extends Model
{
    public $timestamps = false;        
    
}
