<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class ZScoreWeightForLenghtBoy extends Model
{
    
    public $timestamps = false;        
}
