<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class ZScoreWeightForHeightGirl extends Model
{
    
    public $timestamps = false;        
}
