<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class ZScoreWeightForHeightBoy extends Model
{
    public $timestamps = false;        
    
}
