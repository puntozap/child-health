<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class ZScoreWeightBoy extends Model
{
    public $timestamps = false;        
    
}
