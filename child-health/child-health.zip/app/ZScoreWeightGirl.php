<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class ZScoreWeightGirl extends Model
{
    
    public $timestamps = false;        
}
